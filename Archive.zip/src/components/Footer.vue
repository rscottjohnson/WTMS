<template>
  <footer id="custom-footer">
    <span class="mr-4">&copy; 2021 Scott Johnson</span>
    <span class="mr-4">Private</span>
    <span>Terms of Service</span>
  </footer>
</template>